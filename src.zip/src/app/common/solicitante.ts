export class Solicitante {
  nss: string;
  grupoFamiliar: string;
}

