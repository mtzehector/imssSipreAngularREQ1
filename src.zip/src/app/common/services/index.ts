﻿export * from './autorizar.service';
export * from './base.service';
export * from './bitacora.service';
export * from './buscar.folio.imss.service';
export * from './buscar.folio.service';
export * from './cancelar.solicitud.service';
export * from './capacidad.credito.service';
export * from './captura.condiciones.service';
export * from './carga.documento.service';
export * from './carta.capacidad.informe.service.';
export * from './documento.service';
export * from './entidad.financiera.service';
export * from './gaurdado.simulacion.service';
export * from './guardar.carta.capacidad.service';
export * from './guardar.carta.instruccion.capacidad.service';
export * from './guardar.carta.instruccion.service';
export * from './guardar.comprobante.service';
export * from './mensaje.service';
export * from './pensionado.service';
export * from './persona.service';
export * from './plazo.condiciones.service';
export * from './plazo.descuento.service';
export * from './plazo.monto.service';
export * from './plazo.service';
export * from './prestamo.service';
export * from './prestamos.vigentes.service';
export * from './promotor.service';
export * from './resumen.carta.capacidad.service';
export * from './resumen.carta.instruccion.service';
export * from './resumen.simulacion.service';
export * from './simulacion.service';
export * from './titular.service';
export * from './registrar.promotor.service';
export * from './registrar.entidad.financiera.service';
export * from './registrar.notificacion.service';
export * from './catalogo.service';
export * from 'src/app/common/modal-Services/modal.service';
export * from '../../data.service'







