export class Persona {
  id?: string;
  curp?: string;
  nombre?: string;
  primerApellido?: string;
  segundoApellido?: string;
  correoElectronico?: string;
  telefono?: string;
  rfc?:string;
  telefonoCelular?: string;
  firmaCartaRecibo?: number;
}
