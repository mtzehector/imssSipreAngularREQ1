export class OrigenSolicitud{
    id: number;
    desOrigenSolicitud: string;
}