export class BitacoraInterfaz {
    id: number;
    sesion: number;
    idSolicitud: number;
    idTipoServicio: number;
    descRequest: string;
    descRespuesta: string;
    numTiempoResp: number;
    exito: number;
    reponseEndpoint: string;
    endpoint: string;
    cveReporte: number;
}