
export interface Beneficios {
  
  id: number,
  desBeneficio: string

}

