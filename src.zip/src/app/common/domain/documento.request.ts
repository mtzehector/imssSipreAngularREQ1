import { Documento } from './documento';

export class DocumentoRequest {
  documento:Documento;
  contenido:string;
  extencion:"pdf";

}
