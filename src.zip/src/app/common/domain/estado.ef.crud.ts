export class EstadoEfCrud {
  id?: number;
  descripcion?: string;
}
