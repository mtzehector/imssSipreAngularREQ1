
export class EstadoPersonaEF{
    id?:number;
    desEstadoPersonaEf?:string;
}