export interface Plazo {           
     id: number;
     numPlazo: number;
     descripcion: string;
           

}
