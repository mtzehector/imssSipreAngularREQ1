export class DescuentoAplicado {
    nss: string ;
    idInstFinanciera: string ;
    grupoFamiliar: string ;
    razonSocial: string ;
    movimiento: string ;  
    impRecuperado: number ; 
    idSolPrestFinanciero: string ;  
    conceptoNomina: string ;
    periodoNomina: string ;    
    saldoPendiente: number ; 
    desMovimiento: string ;  
}