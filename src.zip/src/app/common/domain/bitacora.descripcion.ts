export class BitacoraDescripcion {
    curp: string;
    Solicitud: string; 
    tipo : string;
    estadoSolicitud : string; 
    altaRegistro : string; 
}