export class BajaPromotorRQ {
    id:number;
    cveEstadoPersonaEf :number;
    cveEntidadFinanciera :number;
    cvePersonalEf : number;
    baja : number;
    email : string;
}