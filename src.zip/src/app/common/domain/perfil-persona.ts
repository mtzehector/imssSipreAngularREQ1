export class PerfilPersona {
    idUsuario: number;
    idPerfil: number;
}