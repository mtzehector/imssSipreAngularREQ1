export class RegistroPatronal{
    id? :   number;
    idEntidadFinanciera? : number;
    registroPatronal? : string;
    fecRegistroAlta?: Date;
    bajaRegistro?: any;
}