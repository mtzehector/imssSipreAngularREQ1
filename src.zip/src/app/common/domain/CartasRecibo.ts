import { CartaRecibo } from "./cartaRecibo";

export class CartasRecibo{

    cartas : CartaRecibo[];
}