export class RegistroOperador {
  curp: string;
  nss: string;
  numTelefono: number;
  correo: string;
  password: string;
  token: string;
  cvePerfil: number;
  matriculaTrabajadorImss: string;
  delegacionTrabajadorImss: string;
  rfc:string;
  registroPatronal:string;
  numEmpleado:string;
  cveEntidadFinanciera:number;
  nombres:string;
  apellido1:string;
  apellido2:string;
  sexo:string;
  fechNac:string;
  desEntidadNac:string;
  
  
}