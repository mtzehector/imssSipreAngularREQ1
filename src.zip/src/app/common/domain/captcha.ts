export class Captcha {
    captchaValueEncrypted: string;
    captchaImageInBase64: string;
}