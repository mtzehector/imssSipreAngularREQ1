
export class ValidarCandidatoOperadorRq {
    curp: string;
    nss: string;
    cveEntidadFinanciera?: number;
    numTelefono?: string;
    correo?: string;
    correoConfirmar?: string;
    cvePerfil?: number;
    matricula?: string;
    delegacion?: string;
}
