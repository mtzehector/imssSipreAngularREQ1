export class Delegacion {
  bajaRegistro?: any;
  fecAltaRegistro?: any;
  desDelegacion?: string;
  descDelegacion?: string;
  numDelegacion?: string;
  id?: number;
  cveDelegacion?: string;
  cve_DELEGACION?: number;
  des_DELEGACION?: number;
}
