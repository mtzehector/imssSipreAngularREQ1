export interface Persona {
  id: string;
  curp: string;
  nombre: string;
  primerApellido: string;
  segundoApellido: string;
  delegacion: string;
  correoElectronico:string;
  telefono:string;
}

