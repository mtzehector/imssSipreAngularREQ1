export class EstadoSolicitudFol{
    id: number;
    desEstadoSolicitud: string;
    desPensionadoEstadoSolicitud: string;
}