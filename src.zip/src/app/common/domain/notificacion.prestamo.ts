import { Persona } from './persona';
import {PrestamoAdjunto} from './prestamo.adjunto';
import { Prestamo } from './prestamo.not';
export class NotificacionPrestamo {

  prestamoResponse: Prestamo = new Prestamo();
  prestamoList?: Prestamo[] = new Array();


}
