import { Captcha } from './captcha';

export class CaptchaGenerarRq {
    response : Captcha;
}