export class BajaOperadorRQ {
    id:number;
    cveEstadoPersonaEf:number;
    cveEntidadFinanciera:number;
    cvePersonalEf:number;
    baja:number;
    email:string;
    sesion:number;
    adminCurp:string;
    cveCurp:string;
}