
export class PageRequest<T> {
  page: number;
  model:T;  
}

