export class InformacionEF {
       registroPatronal: string;
       rfc: string;
       razonSocial: string;
       nombreCompleto: string;
       curp: string;
       estado: string;
       idEntidad?: number;
 }
