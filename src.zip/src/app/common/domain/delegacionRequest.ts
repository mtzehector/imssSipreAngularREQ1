export class DelegacionRequest {
  id: string;
  
}
