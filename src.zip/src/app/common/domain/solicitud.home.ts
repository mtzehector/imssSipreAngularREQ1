export class SolicitudHome {

    cvePromotor: number;
    cveEntidadFinanciera: number;
    solIniciados: number;
    solPendienteMontoLiq: number;
    solPorAutorizar: number;
    solPendienteCargaCEP: number;
    solAsignarPromotor: number;
}