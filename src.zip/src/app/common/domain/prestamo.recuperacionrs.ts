import { PrestamoRecuperacion } from 'src/app/common/domain/prestamo-recuperacion.component';
export class PrestamoEnRecuperacionRs{

    prestamosEnRecuperacion: PrestamoRecuperacion[];
} 