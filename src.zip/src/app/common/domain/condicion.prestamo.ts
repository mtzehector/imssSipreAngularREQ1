import { Plazo } from './plazo';

export class CondicionesPrestamo{
    
 montoSolicitado: string;
  plazo: Plazo;
  cat: string;
  descuentoMensual: string;
  montoPagar: string;

}