
export class SaldoCapitalRequest {
  numMensualidad: number; 
  folioSipre: string; 
  numFolioSolicitud : string;
}
