export class EntidadFinancieraSIPRE {
    idMovimiento?: any;
    entidadPago?: any;
    cveRfc?: any;
    desRazonSocialInst?: any;
    numProveedor?: any;
    catPromedio?: any;
    desRegistroPatronal?: any;
    domFiscal?: any;
    fecFirmaConvenio?: any;
    fecInicioConvenio?: any;
    numClabe?: any;
    numCuenta?: any;
    nomEmail?: any;
    nomRepLegal?:any;
    fecAltaInst?: any;
    estatusLog?: any;
    idLogin?: any;
    fecModificacion?: any;
    fecFinConvenio?: any;
    razonSocial?: any;
    numTel?: any;
    desUrlContacto?: any;
    nomComercial?: any;
    adminRFC?:string;
  }
  
  