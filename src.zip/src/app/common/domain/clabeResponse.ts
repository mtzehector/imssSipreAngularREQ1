

export class ClabeResponse {

    idNss?: any;
    idGrupoFamiliar?: any;
    nomApellidoPaterno?: any;
    nomApellidoMaterno?: any;
    nomNombre?: any;
    cveCurp?: any;
    fecNacimiento?: any;
    idTipoValidacion?: any;
    numClabe?: any;
    idTipoCuentaPago?: any;
    cveCtaPago?: any;

  }