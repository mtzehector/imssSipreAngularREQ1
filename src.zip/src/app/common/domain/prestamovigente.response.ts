import { PrestamosVigentes } from './prestamos.vigentes';
export interface PrestamoVigenteResponse {
  prestamoVigente: PrestamosVigentes[];  
}

