import { Captcha } from './captcha';

export class CaptchaGenerarRs {
    captcha :  Captcha;
}