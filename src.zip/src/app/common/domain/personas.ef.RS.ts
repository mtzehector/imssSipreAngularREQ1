import { PersonaEF } from '../domain/persona.ef';

export class PersonasEfRs {
  cveDelegacion:number;
  cveEntidadFinanciera:number;
  personas: PersonaEF[];
}

 