export class PrestamoMovimiento {
    selectTipoBajas: number;
    motivoBaja: string;
}