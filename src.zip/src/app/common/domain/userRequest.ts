
export class UserRequest {
    userName: string;
    sesion: number;
}