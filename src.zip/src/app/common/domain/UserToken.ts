export class UserToken {
    access_token: string;
    token_type: string;
    expires_in: number;
    acr: string;
    scope: string;
    session: number;
}