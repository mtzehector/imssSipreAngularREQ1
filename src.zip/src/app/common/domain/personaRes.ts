export class PersonaRes {
    cveCurp: string;
}