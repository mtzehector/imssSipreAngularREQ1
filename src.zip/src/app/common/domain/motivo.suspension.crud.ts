export class MotivoSuspensionCrud {
  id?: number;
  desMotivoSuspension?: string;
}
