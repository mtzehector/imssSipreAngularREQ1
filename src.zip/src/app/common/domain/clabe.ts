

export class Clabe {

    idNss ?: any;
    idGrupoFamiliar?: any ;
    clabe?: any ;
  }