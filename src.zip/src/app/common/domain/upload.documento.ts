export class UploadDocumento {
actualizacionRegistro: string;
altaRegistro: string;
bajaRegistro: string;
cadenaOriginal: string;
cveSolicitud: string;
descTipoDocumento: string;
id:string;
idSello: string;
noSerie: string;
refDocBoveda: string;
refDocumento: string;
refSello: string;
sello: string;
tipoDocumento: string;
}

