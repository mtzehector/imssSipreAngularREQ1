import { PersonaRes } from './personaRes';
import { PerfilPersona } from './perfil-persona';

export class Usuario {
    persona: PersonaRes;
    perfilPersona: PerfilPersona;
}