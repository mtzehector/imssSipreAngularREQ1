
export class CondicionEntfedCrud {
  id?: number;
  //cveEntidadFederativa?: number;
  cveDelegacion?: number;
  numEdadLimite?: number;
  monMinimo?: number;
  monMaximo?: number;
  mclcSexo?: any;

}
