
export interface FechaPrimerDescuento {
 nominaPrimerDescuento:string;  
 fecInicio:string;
 fecFin:string;
 fecVigencia:string;
 fecDescNomina:string;
}

