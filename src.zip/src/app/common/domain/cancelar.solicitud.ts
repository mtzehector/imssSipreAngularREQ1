import { Solicitud } from './solicitud';

export class CancelarSolicitud {
  
 solicitud:Solicitud;
  }