export interface Beneficio {
  id?: number;
  desBeneficio?:string; 
  
}

