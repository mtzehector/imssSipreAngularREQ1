export class PrestadorServiciosEF {
    id?: number;
    cveEntidadFinanciera?: number;
    cveTipoPrestadorServicios?: number;
    registroPatronal?: string;
    rfc?: string;
    razonSocial?: string;
    direccion?: string;
    correoElectronico?: string;
    paginaWeb?: string;
    bajaRegistro?: any;
}