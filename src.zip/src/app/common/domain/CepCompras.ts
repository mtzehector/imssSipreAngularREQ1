import { Documento } from ".";

export class CepCompras{
folio: string;
nss: string;
nombre: string;
fechaCarga: string;
sCapital: number;
referencia : string;
documento : Documento;
}