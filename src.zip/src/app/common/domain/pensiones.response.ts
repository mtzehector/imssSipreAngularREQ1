import { Pension } from './pension';
export interface PensionesResponse {
  pensiones: Pension[];  
}

