export class Bancos {
    catalogoBancos: Banco[];

}

export class Banco {
    clave: string;
    descripcion: string;
}