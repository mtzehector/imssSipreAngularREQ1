export class Bitacora {
  curp: string;
  sesion: number;
  idSolicitud: number; 
  tipo : number;
  estadoSolicitud : number; 
  altaRegistro : string;
}

