export class PensionRequest {
  nss: string;  
  grupoFamiliar: string;
  claveDelegacion: string;
  delegacion:string;
  subDelegacion: string;
  entidadFederativa:number;
  curp:string;
  sexo: number;
}

