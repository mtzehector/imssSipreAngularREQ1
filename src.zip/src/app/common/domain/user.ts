
export class User {
    userName: string;
    cvePerfil: number;
    desPerfil: string;
    nombre: string;
    numNss: number;
    primerApellido: string;
    segundoApellido: string;
    cveCurp: string;
    nomUsuario: string;
    desDelegacionTrabIMSS: string;
    matriculaTrabIMSS: string;
}