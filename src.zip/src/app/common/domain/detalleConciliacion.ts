export class DetalleConciliacion {
    id?: number;
    periodo?: string;
    activo?:boolean;
}