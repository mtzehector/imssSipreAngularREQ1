import { ModelRequest } from './model.request';
export class SeleccionFinancieraRequest {  
  page: number;
  model: ModelRequest;  
}

