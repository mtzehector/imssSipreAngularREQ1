export class PersonaPrestamo {
    
    nombre: string;
    primerApellido: string;
    segundoApellido: string;
    telLocal: string;
    correoElectronico: string;
    telCelular: string;
  }