export class EntidadFederativa {
  cveEntidadFederativa: string;
  descEntidadFederativa: string;

}
