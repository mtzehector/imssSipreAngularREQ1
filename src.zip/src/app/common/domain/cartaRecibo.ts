export class CartaRecibo {
    id: number;
    periodo : String;
    proveedor: String;
    rfc: String;
    monto: String;
    montoLetra: String;
    mes: String;
    anio: String;
    primas: String;
    tasa: String;
    iva: String;
    demasia: String;
    neto: String;
    firma: String;
    refDocBoveda: String;
    cveEntFin: string;
    nomComercial :string;
    altaRegistro : string;
}