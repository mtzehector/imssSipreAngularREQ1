export class DocumentacionAutorizar {
    idContrato: number;
    idCartaInstruccion: number;
    idAmortizacion: number;
    idIdentificacionOficial: number;
    refBovedaContrato: string;
    refBovedaCarta: string;
    refBovedaAmortizacion: string; 
    refIdentificacionOficial: string; 
}