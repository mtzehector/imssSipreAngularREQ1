export class PeriodoAmort {
    periodo: number;
    saldo: number;
    capital: number;
    intereses: number;
    iva: number;
    descuento: number;
}