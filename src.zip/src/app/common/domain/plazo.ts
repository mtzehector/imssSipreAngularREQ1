export class Plazo {
id:string
numPlazo:string;
descripcion:string;
}