import { Pensionadorequest } from './pensionado.request';

export class ModelRequest {
  plazo: string;
  tipoSimulacion: string;
  monto:string;
  pensionado: Pensionadorequest;
  
}


