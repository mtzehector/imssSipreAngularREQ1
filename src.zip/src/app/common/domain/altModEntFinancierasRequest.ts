import { EntidadFinancieraSIPRE } from './entidadFinancieraSIPRE';


export class AltModEntFinancierasRequest {
    altModEntFinancierasRequest :EntidadFinancieraSIPRE = new EntidadFinancieraSIPRE();
  }
  
  