export class MontoLiquidar{

    saldoCapital: number;
    solicitudSipre: string;
}