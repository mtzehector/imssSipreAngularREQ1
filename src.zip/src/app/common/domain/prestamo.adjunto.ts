export class PrestamoAdjunto {
 
    id?: number;
    folio?: string;
    nombre?: string;
    primerApellido?: string;
    segundoApellido?: string;
    desPlazo?: string;

  

    }