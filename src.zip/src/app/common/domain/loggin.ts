import { Usuario } from './usuario';

export class Loggin {
    nomUsuario: string;
    password: string;
    usuario: Usuario;
}