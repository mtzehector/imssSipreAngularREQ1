export class SolicitudEstadoRequest{
    idSolicitud?:number;
    idEstado?:number;
}