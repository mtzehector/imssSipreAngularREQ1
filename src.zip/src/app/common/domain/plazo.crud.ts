export class PlazoCrud {
  id?: number;
  descripcion?: string;
  numMeses?: number;
}
