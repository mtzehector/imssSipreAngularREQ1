export class EntidadFinancieraSIPREResponse {
    exito ?: any;
    codigoError?: any;
    mensajeError?: any;
    idInstFinanciera?:any;
  }
  
  