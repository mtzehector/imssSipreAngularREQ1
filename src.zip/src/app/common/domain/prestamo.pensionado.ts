

export class PrestamoPensionado {
id?:number;
monto?:number;
descuentoMensual?:number;
cat?:number;
nomEntidadFinanciera?:string;
}

