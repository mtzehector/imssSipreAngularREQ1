export class NotificacionHome{

    cveEntidadFinanciera: number;
    subTipoCartaLiq: number;
    subTipoCondPrestamo: number;
    subTipoDesDemasia: number;
    subTipoOtroQueja: number;
    subTipoPrestamoNoRec: number;
    subTipoDocumentacion: number;
    subTipoInformacion: number;
    subTipoOtroReq: number;
    subTipoOtroSancion: number;
    subTipoSuspencionDes: number;
    subTipoSuspensionParcial: number;
    subTipoSuspensionTotal: number;
    subTipoTermAnticipada: number;
    subTipoNuevoConc: number;
    subTipoNuevoAviso: number;
    subTipoNuevoComunicado: number;
    estadoNotifRegistradas: number;
    estadoNotifAtendidas: number;
    estadoNotifEnviadas: number;
}