import { Plazo } from './plazo';
export interface PlazosResponse {
  plazos: Plazo[];  
}