export class Mensaje {
  id: string;
  mensaje: string;
  level: string;  
}

