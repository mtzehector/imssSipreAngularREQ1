export class SolicitudesExcel {
    solicitudes: string[] = [];
}