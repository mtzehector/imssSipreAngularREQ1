import { Content } from './content.response';
export interface Ofertaresponse {
 content: Content[];
 last: boolean;
 totalElements: number;
 totalPages: number;
 sort: number;
 first: boolean;
 numberOfElements: number;
 size: number;
 number:number;
  
}

