import{Solicitud} from "./solicitud";
import{Prestamo} from "./prestamo";
export class GuardadoResponse {
  solicitud:Solicitud;
  prestamo:Prestamo;
}

