
export class SaldoCapitalResponse {
  importeMontoSolicitado?: any;
  importeDescuentoMensual?: any;
  importeTotalPagar?: any;
  plazo?: any;
  cat?: any;
  cveSolicitud?: any;
  numMensualidad?: any;
  folioSipre?: any;
  cveTipoSimulacion?: any;
  historico?: any;
  saldoCapital?: any;
}
