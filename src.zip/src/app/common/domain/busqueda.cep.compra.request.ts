export class BusquedaCepCompraRequest{
page:number;
model:Modelo = new Modelo();
}
export class Modelo {

   
    inicio:string;
    fin:string;
    entFinanciera:string;

}