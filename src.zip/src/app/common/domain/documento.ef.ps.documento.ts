import { TipoDocumento } from "./tipo.documento";

export class DocumentoEFPSDocumento {
    id?: number;
    tipoDocumentoEnum?: TipoDocumento;
    altaRegistro?: any;
}