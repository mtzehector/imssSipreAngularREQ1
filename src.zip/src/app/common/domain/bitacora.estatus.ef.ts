export class BitacoraEstatusEF {
    id?: number;
    idEntidadFinanciera?: number;
    idTipoEvento?: number;
    idEstadoEFAnterior?: number;
    idEstadoEFNuevo?: number;
    curp?: string;
}