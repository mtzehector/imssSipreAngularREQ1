export class TitularGrupoRequest {
  idNss: string;
  idGrupoFamiliar: string;
}
