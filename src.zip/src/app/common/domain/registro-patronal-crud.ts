import { RegistroPatronal } from './registro-patronal'
export class RegistroPatronalCrud {

    registrosPatronales? : RegistroPatronal[];

}