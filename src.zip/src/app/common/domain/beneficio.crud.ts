export class BeneficioCrud {
  id?: number;
  desBeneficio?: string;
}
