export class Pensionado{
    cvePersona: string;
    cveCurp: string;
    numNss: string;
    nombre: string;
    primerApellido: string;
    segundoApellido: string;
    correoElectronico: string;
    telCelular: string;
    telLocal: string;
}