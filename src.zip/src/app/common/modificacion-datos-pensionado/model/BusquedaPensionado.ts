export class BusquedaPensionado{
    curp: string;
    numNss: string;
}