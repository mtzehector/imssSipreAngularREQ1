export class TipoModificacion {
    id: number;
    altaRegistro: string;
    cveTipoModificacion: number;
    nombreTipoModificacion: string;
}