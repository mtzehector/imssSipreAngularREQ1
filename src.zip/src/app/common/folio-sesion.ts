export class FolioSesion {
  
  folioSesion: string;

}

