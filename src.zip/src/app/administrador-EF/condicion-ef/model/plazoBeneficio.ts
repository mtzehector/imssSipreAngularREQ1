
export class PlazoBeneficio {
        id: number;
        plazo:string;
        cat:number;
        catForm:number;
        idBeneficioA:number;
        valorBeneficioA:string;
        idBeneficioB:number;
        valorBeneficioB:string;
        idBeneficioC:number;
        valorBeneficioC:string;
        error:boolean=false;
        mensajeError:string;
        indice:number;
  
}

