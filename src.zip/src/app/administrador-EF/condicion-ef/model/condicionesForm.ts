import { NumberValueAccessor } from '@angular/forms';

export class CondicionesForm {
    
 
    //---entidadFederativa:number;
    delegacion:number;
    edad:string;
    sexo:string;
    mMinimo:number;
    mMax:number ;
    paginaWeb:string;
    condiciones:string;
    plazosBeneficios:string;
  
}