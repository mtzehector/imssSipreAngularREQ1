export class Beneficio {
 
        nombre:string;
        id:number;
        seleccionado:number=0;
  
}