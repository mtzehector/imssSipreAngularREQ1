
export class InformacionEF {
       registroPatronal:string;
       rfc:string;
       razonSocial:string;
       nombreCompleto:string;
       curp:string;
       nombreRL:string;
       aPaternoRL:string;
       aMaternoRL:string;
       nombreComercial:string;
     
       /* DATOS DEL CONTACTO */ 
       telefono:number;
       telefonoCliente:number;
       paginaWeb:string;
       correoElectronico:string[];
       domicilio:string;
       /* DATOS DEL CONVENIO */ 
       fechaInicioConvenio:string;
       fechaFirmaConvenio:string;
       numeroProvedor;


   
    }
    
    

    