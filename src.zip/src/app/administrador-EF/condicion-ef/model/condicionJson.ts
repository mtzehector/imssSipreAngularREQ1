export class CondicionJson {
 
    id:number;
    //---entidadFederativaJ:number;
    delegacionJ:number;
    //---nombreEF:string;
    nombreDelegacion:string;
    edadJ:string;
    sexoJ:string;
    mMinimoJ:number;
    mMaxJ:number ;
    //********  NUEVO  */
    editar:boolean=true;

    //---entidadFederativaE:number;
    delegacionE:number;
    sexoE:string;
    mMinimoE:number;
    edadE:string;
    mMaxE:number ;


  
}