import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadcrumb-ux',
  templateUrl: './breadcrumb-ux.component.html',
  styleUrls: ['./breadcrumb-ux.component.css']
})
export class BreadcrumbUxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
